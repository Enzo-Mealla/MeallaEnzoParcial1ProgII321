
package acuario;


public class moluscos extends especieMarina implements alimentacion { 
    
    private String tipoConcha;

    public moluscos(String tipoConcha, String nombre, String tanque, tipoAgua tipoAgua) {
        super(nombre, tanque, tipoAgua);
        this.tipoConcha = tipoConcha;
    }
    
    @Override
    public void alimentar(){
        System.out.println(getNombre() + " esta comiendo");
    }
    
}
