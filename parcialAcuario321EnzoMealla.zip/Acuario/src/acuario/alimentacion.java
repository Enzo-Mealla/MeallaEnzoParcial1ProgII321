
package acuario;


public interface alimentacion {
    void alimentar();
}
