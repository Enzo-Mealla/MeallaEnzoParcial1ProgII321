
package acuario;


public class Acuario {

    
    public static void main(String[] args) {
        
        
        //me falto completar excepciones y el main.
        
        peces p1 = new peces("asd123");
        
    }
    
}
