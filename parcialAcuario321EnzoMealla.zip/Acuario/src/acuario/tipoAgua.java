
package acuario;


public enum tipoAgua {
    AGUA_SALADA,
    AGUA_DULCE,
    
}
