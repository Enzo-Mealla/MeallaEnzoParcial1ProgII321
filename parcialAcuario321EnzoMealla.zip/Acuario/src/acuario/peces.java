
package acuario;


public class peces extends especieMarina implements alimentacion{
    
    private double longMaxCm;

    public peces(double longMaxCm, String nombre, String tanque, tipoAgua tipoAgua) {
        super(nombre, tanque, tipoAgua);
        this.longMaxCm = longMaxCm;
    }
    
    
    @Override
    public void alimentar(){
        System.out.println(getNombre() + "esta comiendo");
    }

    



    
    
    
}
