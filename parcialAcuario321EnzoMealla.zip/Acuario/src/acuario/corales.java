
package acuario;


public class corales extends especieMarina {
    private double profCrecimiento;

    public corales(double profCrecimiento, String nombre, String tanque, tipoAgua tipoAgua) {
        super(nombre, tanque, tipoAgua);
        this.profCrecimiento = profCrecimiento;
    }
    
    
    
}
