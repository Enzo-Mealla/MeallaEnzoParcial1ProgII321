
package acuario;

public abstract class especieMarina {
    
    private String nombre;
    private String tanque;
    private tipoAgua tipoAgua;

    public especieMarina(String nombre, String tanque, tipoAgua tipoAgua) {
        this.nombre = nombre;
        this.tanque = tanque;
        this.tipoAgua = tipoAgua;
    }
    
    public void reproducirse(){
        System.out.println( nombre + "se reproduce");
    }
    
    public void respirar(){
        System.out.println(nombre + "respira");
    }
    
    
    public String getNombre() {
        return nombre;
        
        
    }
    
    public String getTanque(){
        return tanque;
        
    }
    public tipoAgua gettipoAgua(){
        return tipoAgua;
    }
}
